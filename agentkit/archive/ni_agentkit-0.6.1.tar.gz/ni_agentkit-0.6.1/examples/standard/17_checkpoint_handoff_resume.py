"""
示例 17：Checkpoint + Handoff + Resume（执行指针恢复）

目标：
1. RootAgent 先 handoff 到 ReviewAgent；
2. ReviewAgent 请求人工输入并挂起；
3. resume 后从 ReviewAgent 继续（而不是回到 RootAgent）。
"""
from __future__ import annotations

import asyncio
from typing import AsyncGenerator

from agentkit.agents.base_agent import BaseAgent
from agentkit.runner.context import RunContext
from agentkit.runner.context_store import InMemoryContextStore
from agentkit.runner.events import Event, EventType
from agentkit.runner.runner import Runner


class ReviewAgent(BaseAgent):
    async def _run_impl(self, ctx: RunContext) -> AsyncGenerator[Event, None]:
        # 第一次进入：请求人工输入并挂起
        if not ctx.state.get("review_suspended_once"):
            ctx.state["review_suspended_once"] = True
            suspension = ctx.register_suspension(
                tool_call_id="manual-review-1",
                tool_name="manual_review",
                prompt="请审批该任务（approve/reject）",
            )
            yield Event(
                agent=self.name,
                type=EventType.SUSPEND_REQUESTED,
                data={
                    "suspension_id": suspension.suspension_id,
                    "prompt": "请审批该任务（approve/reject）",
                    "tool": "manual_review",
                    "tool_call_id": "manual-review-1",
                },
            )
            return

        # 恢复后：读取 resume 注入的 tool message
        tool_msgs = [m for m in ctx.messages if m.get("role") == "tool" and m.get("tool_call_id") == "manual-review-1"]
        decision = tool_msgs[-1].get("content", "unknown") if tool_msgs else "unknown"
        yield Event(agent=self.name, type=EventType.FINAL_OUTPUT, data=f"Review completed: {decision}")


class RootAgent(BaseAgent):
    async def _run_impl(self, ctx: RunContext) -> AsyncGenerator[Event, None]:
        yield Event(agent=self.name, type=EventType.HANDOFF, data={"target": "reviewer"})


async def main() -> None:
    root = RootAgent(name="root")
    reviewer = ReviewAgent(name="reviewer")
    root.sub_agents.append(reviewer)
    reviewer.parent_agent = root

    store = InMemoryContextStore()
    session_id = "demo-handoff-checkpoint-001"

    print("=== 阶段 1：运行并挂起 ===")
    async for event in Runner.run_with_checkpoint(
        root,
        input="请审批部署任务",
        session_id=session_id,
        context_store=store,
        max_turns=5,
    ):
        print(f"[run] {event.type} | agent={event.agent} | data={event.data}")

    print("\n=== 阶段 2：恢复并完成 ===")
    async for event in Runner.resume(
        root,
        session_id=session_id,
        user_input="approve",
        context_store=store,
    ):
        print(f"[resume] {event.type} | agent={event.agent} | data={event.data}")


if __name__ == "__main__":
    asyncio.run(main())
