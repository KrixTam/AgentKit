"""
agentkit/llm/adapters/ollama_adapter.py — Ollama 本地模型适配器

使用 Ollama 原生 /api/chat 接口（非 OpenAI 兼容接口），因为：
1. 原生 API 响应更快（避免 thinking 模式下 OpenAI 兼容接口的问题）
2. 原生支持 function calling（tool_calls）
3. 直接获取最终 content（不需要处理 reasoning 字段）

支持模型：所有 Ollama 本地模型（如 qwen3.5:4b, llama3, gemma 等）
"""
from __future__ import annotations

import json
import logging
from typing import Any, AsyncGenerator, Optional

from ..base import BaseLLM
from ..types import (
    FinishReason,
    LLMConfig,
    LLMResponse,
    Message,
    MessageRole,
    StreamChunk,
    ToolCall,
    ToolDefinition,
    Usage,
)

logger = logging.getLogger("agentkit.llm.ollama")

# Ollama 默认端点
DEFAULT_OLLAMA_BASE = "http://localhost:11434"


class OllamaAdapter(BaseLLM):
    """Ollama 本地模型适配器（使用原生 /api/chat 接口）"""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        self._base_url = (config.api_base or DEFAULT_OLLAMA_BASE).rstrip("/")
        # Ollama 本地模型推理较慢（尤其 thinking 模式），自动放宽超时
        if self.config.timeout <= 60:
            self.config.timeout = 120

    @property
    def _think_enabled(self) -> bool:
        """是否启用 thinking（深度思考）模式，默认 True"""
        return self.config.extra_params.get("think", True)

    def _inject_no_think(self, messages: list[Message]) -> list[Message]:
        """
        当 think=False 时，在 system prompt 末尾追加 /no_think 标记，
        告诉 qwen3.5 等支持 thinking 的模型跳过深度思考，直接输出结果。
        这能让响应速度提升 2-5 倍。
        """
        if self._think_enabled:
            return messages

        result: list[Message] = []
        for msg in messages:
            if msg.role == MessageRole.SYSTEM and msg.content:
                result.append(Message(
                    role=msg.role,
                    content=msg.content + "\n\n/no_think",
                    tool_calls=msg.tool_calls,
                    tool_call_id=msg.tool_call_id,
                ))
            else:
                result.append(msg)
        return result

    async def generate(
        self,
        messages: list[Message],
        *,
        tools: list[ToolDefinition] | None = None,
        tool_choice: str | None = None,
        output_schema: type | None = None,
    ) -> LLMResponse:
        import aiohttp

        # 如果关闭了 thinking，注入 /no_think 标记
        messages = self._inject_no_think(messages)

        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": [self._convert_message(m) for m in messages],
            "stream": True,  # 始终用流式，逐 token 读取避免超时
            "options": {
                "temperature": self.config.temperature,
                "top_p": self.config.top_p,
            },
        }
        if self.config.max_tokens:
            payload["options"]["num_predict"] = self.config.max_tokens

        if tools:
            payload["tools"] = [self._convert_tool(t) for t in tools]

        if output_schema:
            payload["format"] = output_schema.model_json_schema()

        url = f"{self._base_url}/api/chat"

        # 使用流式读取收集完整响应（避免 thinking 模型长时间阻塞导致超时）
        # sock_read 设大：thinking 模式下第一个 token 可能需要数分钟
        timeout = aiohttp.ClientTimeout(total=None, sock_read=600)

        content_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        final_data: dict = {}

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=timeout) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    raise RuntimeError(f"Ollama API 错误 ({resp.status}): {text}")

                async for line in resp.content:
                    line_text = line.decode("utf-8").strip()
                    if not line_text:
                        continue
                    try:
                        chunk = json.loads(line_text)
                    except json.JSONDecodeError:
                        continue

                    msg = chunk.get("message", {})
                    if msg.get("content"):
                        content_parts.append(msg["content"])

                    # 工具调用出现在最后一个 chunk
                    if msg.get("tool_calls"):
                        for tc in msg["tool_calls"]:
                            func_data = tc.get("function", {})
                            tool_calls.append(ToolCall(
                                id=tc.get("id", f"call_{func_data.get('name', 'unknown')}"),
                                name=func_data.get("name", ""),
                                arguments=func_data.get("arguments", {}),
                            ))

                    if chunk.get("done"):
                        final_data = chunk
                        break

        content = "".join(content_parts).strip() or None
        finish_reason = FinishReason.TOOL_CALLS if tool_calls else FinishReason.STOP
        usage = Usage(
            prompt_tokens=final_data.get("prompt_eval_count", 0),
            completion_tokens=final_data.get("eval_count", 0),
        )

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            usage=usage,
            model=final_data.get("model", self.config.model),
            _raw=final_data,
        )

    async def generate_stream(
        self,
        messages: list[Message],
        *,
        tools: list[ToolDefinition] | None = None,
        tool_choice: str | None = None,
    ) -> AsyncGenerator[StreamChunk, None]:
        import aiohttp

        messages = self._inject_no_think(messages)

        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": [self._convert_message(m) for m in messages],
            "stream": True,
            "options": {
                "temperature": self.config.temperature,
            },
        }
        if tools:
            payload["tools"] = [self._convert_tool(t) for t in tools]

        url = f"{self._base_url}/api/chat"

        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=None, sock_read=600),
            ) as resp:
                async for line in resp.content:
                    line_text = line.decode("utf-8").strip()
                    if not line_text:
                        continue
                    try:
                        chunk_data = json.loads(line_text)
                    except json.JSONDecodeError:
                        continue

                    msg = chunk_data.get("message", {})
                    content = msg.get("content", "")
                    done = chunk_data.get("done", False)

                    if content:
                        yield StreamChunk(delta_content=content)
                    if done:
                        yield StreamChunk(finish_reason=FinishReason.STOP)

    # ------------------------------------------------------------------
    # 内部转换
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_message(msg: Message) -> dict:
        """框架消息 → Ollama 消息"""
        result: dict[str, Any] = {"role": msg.role.value, "content": msg.content or ""}

        if msg.role == MessageRole.ASSISTANT and msg.tool_calls:
            result["tool_calls"] = [
                {
                    "id": tc.id,
                    "function": {
                        "name": tc.name,
                        "arguments": tc.arguments,  # Ollama 接受 dict
                    },
                }
                for tc in msg.tool_calls
            ]

        if msg.role == MessageRole.TOOL:
            result["role"] = "tool"
            result["content"] = msg.content or ""

        return result

    @staticmethod
    def _convert_tool(tool: ToolDefinition) -> dict:
        """框架工具定义 → Ollama 工具格式"""
        return {
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
            },
        }

    @staticmethod
    def _parse_response(data: dict) -> LLMResponse:
        """Ollama 响应 → 框架响应"""
        msg = data.get("message", {})
        content = msg.get("content", "") or ""
        raw_tool_calls = msg.get("tool_calls", [])

        tool_calls: list[ToolCall] = []
        for tc in raw_tool_calls:
            func_data = tc.get("function", {})
            tool_calls.append(ToolCall(
                id=tc.get("id", f"call_{func_data.get('name', 'unknown')}"),
                name=func_data.get("name", ""),
                arguments=func_data.get("arguments", {}),
            ))

        # 判断结束原因
        if tool_calls:
            finish_reason = FinishReason.TOOL_CALLS
        elif data.get("done", False):
            finish_reason = FinishReason.STOP
        else:
            finish_reason = FinishReason.LENGTH

        # 解析 token 用量
        usage = Usage(
            prompt_tokens=data.get("prompt_eval_count", 0),
            completion_tokens=data.get("eval_count", 0),
        )

        return LLMResponse(
            content=content.strip() if content else None,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            usage=usage,
            model=data.get("model", ""),
            _raw=data,
        )

    def supports_tool_calling(self) -> bool:
        # Ollama 支持部分模型的 tool calling
        return True

    def supports_structured_output(self) -> bool:
        return True  # Ollama 支持 format 参数
